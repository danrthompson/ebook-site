<?php
/*
Plugin Name: Playne Shortcodes
Plugin URI: http://themeforest.net/user/playnethemes
Description: Free shortcodes for use with my themes or any other themes you might like. You can enter the shortcodes from your text editor after installing this plugin.
Author: PlayneThemes
Author URI: http://themeforest.net/user/playnethemes
Version: 1.0
License: GNU General Public License version 3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/

include('includes/scripts.php'); 
include('includes/functions.php'); 
include('includes/mce/tinymce.php'); 
